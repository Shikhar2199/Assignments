package com.yash;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ReadDOM 
{
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException 
	{

		File xmlFile=new File("D:\\Assignments\\16 Sept\\XML_Project\\src\\employee.xml");
		//InputStream is=ClassLoader.getSystemResourceAsStream("employees.xml");
		
		DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
		Document document=documentBuilder.parse(xmlFile);
		document.getDocumentElement().normalize();
		String rootElement=document.getDocumentElement().getNodeName();
		System.out.println("Root Element:"+rootElement);
		
		NodeList nodeList=document.getElementsByTagName("employee");

		Node node1 = nodeList.item(0);
		System.out.println(node1.getNodeName());
		
		for(int i=0;i<nodeList.getLength();i++) 
		{
			Node node=nodeList.item(i);
			System.out.println("Node Name:"+node.getNodeName());
			if(node.getNodeType()==Node.ELEMENT_NODE) {
				Element element=(Element)node;
				System.out.println("Emp Id:"+element.getAttribute("employeeId"));
			    System.out.println("Emp Name:"+element.getElementsByTagName("firstname").item(0).getTextContent());
				System.out.println("Emp Designation:"+element.getElementsByTagName("desig").item(0).getTextContent());
}
			
		}
		
	}
}
