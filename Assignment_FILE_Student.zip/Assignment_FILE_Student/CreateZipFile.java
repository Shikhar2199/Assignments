package Assignment_FILE_Student;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class CreateZipFile 
{

	public void makeFile(ArrayList<Student> Students)
	{
		
		 try {  
			 	String st ="";
			 	for(int i=0 ; i<Students.size();i++) 
			 	{
			 		Student s = (Student) Students.get(i);
			 		st = st +" "+ s.getRollNo() +" "+ s.getStudentName() +" :-  "+ s.getSem1() +" , "+ s.getSem2() +" , "+ s.getSem3() +" -- "+ s.getPercentage()+"% \n";
			 	}
		        FileWriter fileWrite = new FileWriter("D:\\FileIO\\Student.dat");  
		        fileWrite.write(st);   
		        fileWrite.close();   
		        System.out.println("File Made");
		        
		    } catch (IOException e) {  
		        System.out.println("Unexpected error occurred");  
		        e.printStackTrace();  
		        }  
	}
	
	
	public void MakeZip()
	{
	
				try(
					InputStream is=new FileInputStream("D:\\FileIO\\Student.dat");
					OutputStream os=new FileOutputStream("D:\\FileIO\\Sample.zip");
					ZipOutputStream zos=new ZipOutputStream(os);
				  )
				{
					ZipEntry zipEntry=new ZipEntry("Students.dat");
					zos.putNextEntry(zipEntry);
					byte[] buffer=new byte[1024];
					int k;
					while((k=is.read(buffer))>0) {
						zos.write(buffer,0,k);
					}
					zos.closeEntry();
				}
				catch(IOException e) 
				{
					System.err.println("--Error--");
					e.printStackTrace();
				}
		}

}