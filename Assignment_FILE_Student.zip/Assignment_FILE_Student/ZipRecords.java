package Assignment_FILE_Student;

import java.util.ArrayList;
import java.util.Scanner;

public class ZipRecords {

	public static void main(String[] args) 
	{
		CreateZipFile z = new CreateZipFile();
		
		ArrayList<Student> st = new ArrayList<Student>();
		try(Scanner sc = new Scanner(System.in))
		{
			int N=0; 
			int RollNo =0;
			String Name = null;
			int[] Marks = {0,0,0};
			
			System.out.println("Number of records ?");
			if(sc.hasNextInt())
			{
				N = sc.nextInt();
			}
			else
			{
				System.err.println("Invalid Number");
			}
			
			for(int i = 1; i<=N ; i++) 
			{
				Student s = new Student();
				System.out.println("Enter Name : ");
				Name = sc.next();
				//Validate Name
				System.out.println("Enter Roll No : ");
				if(sc.hasNextInt())
				{
					RollNo = sc.nextInt();
				}
				else
				{
					System.err.println("Invalid Roll No");
				}
				for(int j = 0 ; j<=2 ; j++)//---------For Fetching marks Array (int[]) 
				{
					
					System.out.println("Enter Semester "+ j +" Marks : ");
					if(sc.hasNextInt())
					{
						Marks[j]=sc.nextInt();
					}
				}
				float per = Percentage(Marks);
				
				s.setRollNo(RollNo);
				s.setStudentName(Name);
			    s.setSem1(Marks[0]);
			    s.setSem2(Marks[1]);
			    s.setSem3(Marks[2]);
			    s.setPercentage(per);
			    st.add(s);
			}
			
		    
		   
		 // System.out.println(st.toString());
		  z.makeFile(st);
		  z.MakeZip();
		}
		catch(Exception e)
		{
			
		}
		
	}

	
	public static float Percentage(int[] marks)
	{
		int sum=0;
		float per=0;
		for(int i=0;i<3;i++)
		{
			sum+=marks[i];
		}
		per=sum/(marks.length);
		return per;
		
	}
	

}

