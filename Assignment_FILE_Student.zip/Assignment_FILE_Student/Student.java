package Assignment_FILE_Student;

public class Student {
	
	 int RollNo;
	 String StudentName;
	 int Sem1;
	 int Sem2;
	 int Sem3;
	 float percentage;
	 
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	@Override
	public String toString() {
		return "Student [RollNo=" + RollNo + ", StudentName=" + StudentName + ", Sem1=" + Sem1 + ", Sem2=" + Sem2
				+ ", Sem3=" + Sem3 +", Percentage="+percentage+ "]";
	}
	public int getRollNo() {
		return RollNo;
	}
	public void setRollNo(int rollNo) {
		RollNo = rollNo;
	}
	public String getStudentName() {
		return StudentName;
	}
	public void setStudentName(String studentName) {
		StudentName = studentName;
	}
	public int getSem1() {
		return Sem1;
	}
	public void setSem1(int sem1) {
		Sem1 = sem1;
	}
	public int getSem2() {
		return Sem2;
	}
	public void setSem2(int sem2) {
		Sem2 = sem2;
	}
	public int getSem3() {
		return Sem3;
	}
	public void setSem3(int sem3) {
		Sem3 = sem3;
	}
	 
}
